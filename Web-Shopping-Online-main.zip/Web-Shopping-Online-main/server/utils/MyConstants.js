const MyConstants = {
    DB_SERVER: 'cluster0.h7uxtpy.mongodb.net',
    DB_USER: 'hieudo0912',
    DB_PASS: '0354688354sao1',
    DB_DATABASE: 'shoppingonline',
    JWT_SECRET: 'Hieudo',
    JWT_EXPIRES: '3600000', // in milliseconds
    EMAIL_USER: 'doconghieu0912@gmail.com', // gmail service
    EMAIL_PASS: 'rfsnnwhrbzwuijbl'
  };
  module.exports = MyConstants;